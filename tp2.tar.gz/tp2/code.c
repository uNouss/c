#include <stdio.h>

const char CLE = "SECRET";

int main(){
    
}
